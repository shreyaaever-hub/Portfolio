# Shreyaaever — pitch deck (static, no build)

GitHub: new repo -> upload index.html, assets/, vercel.json -> commit.
Vercel: vercel.com -> Add New -> Project -> import repo -> Framework "Other" -> Deploy.
(or drag-drop this folder on vercel.com/new)
